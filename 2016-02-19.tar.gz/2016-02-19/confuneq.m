function [c,ceq]=confuneq(x)
c=[];
ceq=x(1)^2+x(2)-1;
