function [c,ceq]=confuneq2(x)
c=-x(1)*x(2)-10;
ceq=x(1)^2+x(2)-1;
