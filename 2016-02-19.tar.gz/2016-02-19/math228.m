x0=[-1,1];
options=optimset('largescale','off');
[x,fval,exitflag,output]=fmincon('objfun',x0,[],[],[],[],[],[],'confuneq2',options);
x
fval
exitflag
output