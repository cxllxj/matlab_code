clf reset,t=(0:20)/20;r=2.5-cos(2*pi*t);[x,y,z]=cylinder(r,40);
fc=get(gca,'color');
h=surface(x,y,z,'FaceColor',fc,'EdgeColor','flat','FaceLighting','none','EdgeLighting','flat');
view(3);grid on;axis off
set(h,'FaceColor','flat','LineStyle','-','EdgeColor',[.8 .8 .8])
set(h,'FaceColor','interp','MeshStyle','column')