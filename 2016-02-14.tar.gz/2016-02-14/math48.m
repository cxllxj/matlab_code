%H_fig=figure
%set(H_fig,'MenuBar','none');
%set(gcf,'menubar',menubar);
%set(gcf,'menubar','figure');
figure
h_menu=uimenu(gcf,'label','Color');
h_submenu1=uimenu(h_menu,'label','Blue','callback','set(gcf,''Color'',''blue'')');
h_submenu2=uimenu(h_menu,'label','Red','callback','set(gcf,''Color'',''red'')');