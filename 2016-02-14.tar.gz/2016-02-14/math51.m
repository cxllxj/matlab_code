figure
BackColor=get(gcf,'Color');
h_menu=uimenu('label','Option','Position',3);
h_sub1=uimenu(h_menu,'label','grid on','callback','grid on');
h_sub2=uimenu(h_menu,'label','grid off','callback','grid on');
h_sub3=uimenu(h_menu,'label','box on','callback','box on','separator','on');
h_sub4=uimenu(h_menu,'label','box off','callback','box off');
h_sub5=uimenu(h_menu,'label','Figure Color','Separator','on');
h_subsub1=uimenu(h_sub5,'label','Red','ForeGroundColor','r','callback','set(gcf,''Color'',''r'')');
h_subsub2=uimenu(h_sub5,'label','Reset','callback','set(gcf,''Color'',BackColor)');
%��ѯλ��ֵ����
Pos_O=get(h_menu,'position'),
Pos_BoxOn=get(h_sub3,'position')
Pos_Red=get(h_subsub1,'position')

