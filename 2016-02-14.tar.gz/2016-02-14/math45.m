function textzzy(arg)
%run with bugs
if ~nargin;arg=0;end
if ischar(arg) | iscell(arg)
    PT.Units='normalized';
    PT.Postion=[0.01 0.01];
    PT.String=arg;
    PT.HorizontalAlignment='left';
    PT.VerticalAlignment='baseline';
    ht=text(PT);
    textzzy(0)
elseif arg==0
    hf=get(0,'CurrentFigure');
    if isempty(hf)
        error('ͼ�δ������ڡ�')
    end
    PF1.BackingStore='off';
    PF1.WindowButtonDownFcn='textzzy(1)';
    set(hf,PF1)
    figure(hf)
elseif arg==1 & strcmp(get(gco,'Type'),'text')
    P01.Units='data';
    P01.EraseMode='xor';
    P01.HorizontalAlignment='left';
    P01.VerticalAlignment='baseline';
    set(gco,P01)
    PF2.Pointer='fleur';
    PF2.WindowButtonMotionFcn='textzzy(2)';
    PF2.WindowButtonUpFcn='textzzy(999)';
    set(gcf,PF2)
elseif arg==2
    curpoi=get(gca,'CurrentPoint');
    set(gco,'Position',curpoi(1,1:3))
elseif arg==999
    set(gco,'EraseMode','normal')
    PF3.WindowButtonDownFcn='';
    PF3.WindowButtonMotionFcn='';
    PF3.WindowButtonUpFcn='';
    PF3.Pointer='arrow';
    PF3.Units='pixels';
    PF3.BackingStore='on';
    set(gcf,PF3)
else
    PF4.WindowButtonDownFcn='';
    PF4.WindowButtonMotionFcn='';
    PF4.WindowButtonUpFcn='';
    PF4.Pointer='arrow';
    PF4.Units='pixels';
    PF4.BackingStore='on';
    set(gcf,PF4)
end