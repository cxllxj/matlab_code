clf reset,t=(0:20)/20;r=2.5-cos(2*pi*t);
[x,y,z]=cylinder(r,40);
[C,CMAP]=imread('trees.tif');
CC=double(C)+1;
surface(x,y,z,'Cdata',flipud(CC),'FaceColor','texturemap','EdgeColor','none','CDataMapping','direct','Ambient',0.6,'diffuse',0.8,'speculars',0.9)
colormap(CMAP)
view(3),axis off