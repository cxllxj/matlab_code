%run with some bugs
clf
h_menu=uimenu('label','Option');
h_sub1=uimenu(h_menu,'label','Axis on');
h_sub2=uimenu(h_menu,'label','Axis off','enable','off');
h_sub3=uimenu(h_menu,'label','Grid on','separator','on','visible','off');
h_sub4=uimenu(h_menu,'label','Grid off','visible','off');
set(h_sub1,'callback',['Axis on,','set(h_sub1,''enable'',''off''),','set(h_sub2,''enable'',''on''),','set(h_sub3,''visible'',''on''),','set(h_sub4,''visible'',''on''),']);
set(h_sub2,'callback',['Axis off,','set(h_sub1,''enable'',''on''),','set(h_sub2,''enable'',''off''),','set(h_sub3,''visible'',''off''),','set(h_sub4,''visible'',''off''),']);
set(h_sub3,'callback',['grid on,','set(h_sub3,''enable'',''off''),','set(h_sub4,''enable'',''on''),']);
set(h_sub4,'callback',['grid off,','set(h_sub3,''enable'',''on''),','set(h_sub4,''enable'',''off''),']);


