figure
h_menu=uimenu('label','Option');
h_sub1=uimenu(h_menu,'label','Grid on','callback',['grid on,','set(h_sub1,''checked'',''on''),','set(h_sub2,''checked'',''off''),',]);
h_sub2=uimenu(h_menu,'label','Grid off','callback',['grid off,','set(h_sub2,''checked'',''on''),','set(h_sub1,''checked'',''off''),',]);