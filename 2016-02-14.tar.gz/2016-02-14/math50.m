figure
h_menu=uimenu(gcf,'Label','&Color');
h_submenu1=uimenu(h_menu,'Label','&Blue','Callback','set(gcf,''color'',''blue'')');
h_submenu2=uimenu(h_menu,'label','Red','Callback','set(gcf,''color'',''red'')','Accelerator','r');
