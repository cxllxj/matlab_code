grid on,set(gca,'box','on')
eval('grid on,set(gca,''box'',''on'')')
uimenu('Label','Test','Callback','grid on,set(gca,''box'',''on''),')
uimenu('Label','Test','Callback',['grid on','set(gca,''box'',''on'');'])
Lpv='Test';
Cpv=['grid on,','set(gca,''box'',''on''),'];
uimenu('Label',Lpv,'Callback',Cpv)
PS.Label='Test';
PS.Callback=['grid on;','set(gca,''box'',''on'');'];
uimenu(PS)
