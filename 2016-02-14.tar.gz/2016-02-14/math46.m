%run math46,use parameters follow:
%0.3
%0.1:0.1:1
clf reset
H=axes('unit','normalized','position',[0,0,1,1],'visible','off');
set(gcf,'currentaxes',H);
str='\fontname{����}��һ������ϵͳ�Ľ�Ծ��Ӧ����';
text(0.12,0.93,str,'fontsize',13);
h_fig=get(H,'parent');
set(h_fig,'unit','normalized','position',[0.1,0.2,0.7,0.4]);
h_axes=axes('parent',h_fig,'unit','normalized','position',[0.1,0.15,0.55,0.7],'xlim',[0 15],'ylim',[0 1.8],'fontsize',8);


h_text=uicontrol(h_fig,'style','text','unit','normalized','position',[0.67,0.73,0.25,0.14],'horizontal','left','string',{'���������ϵ��','zeta ='});
h_edit=uicontrol(h_fig,'style','edit','unit','normalized','position',[0.67,0.59,0.25,0.14],'horizontal','left','callback',['z=str2num(get(gcbo,''string''));','t=0:0.1:15;','for k=1:length(z);','y(:,k)=step(1,[1 2*z(k) 1],t);','plot(t,y(:,k));','if (length(z)>1),hold on,end,','end;','hold off,']);

h_push1=uicontrol(h_fig,'style','push','unit','normalized','position',[0.67,0.37,0.12,0.15],'string','grid on','callback','grid on');
h_push2=uicontrol(h_fig,'style','push','unit','normalized','position',[0.67,0.15,0.12,0.15],'string','grid off','callback','grid off');