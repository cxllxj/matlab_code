% right click the dots one the wave and select the color red,blue or green
t=(-3*pi:pi/50:3*pi)+eps;
y=sin(t)./t;
hline=plot(t,y);
cm=uicontextmenu;
uimenu(cm,'label','Red','callback','set(hline,''color'',''r''),')
uimenu(cm,'label','Blue','callback','set(hline,''color'',''b''),')
uimenu(cm,'label','Green','callback','set(hline,''color'',''g''),')
set(hline,'uicontextmenu',cm)