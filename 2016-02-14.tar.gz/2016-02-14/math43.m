clf reset,k=8;
X=[0 1 1 0;1 1 1 1;1 0 0 1;0 0 0 0;0 1 1 0;0 1 1 0]';
Y=5*[0 0 0 0;0 1 1 0;1 1 1 1;1 0 0 1;0 0 1 1;0 0 1 1]';
Z=[0 0 1 1;0 0 1 1;0 0 1 1;0 0 1 1;0 0 0 0;1 1 1 1]';
FC=k:(k+size(Z,2)-1);
patch(X,Y,Z,FC),set(gca,'Projection','pers')
view([-20 -12]),colormap(jet),axis equal off