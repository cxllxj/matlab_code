H_fig=figure
set(H_fig,'MenuBar','none');
set(gcf,'menubar',menubar);
set(gcf,'menubar','figure');
