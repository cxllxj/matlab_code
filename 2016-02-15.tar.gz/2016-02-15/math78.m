L=linspace(0,2.*pi,6);
xv=cos(L)';
yv=sin(L)';
xv=[xv;xv(1)];yv=[yv;yv(1)];
x=randn(250,1);y=randn(250,1);
in=inpolygon(x,y,xv,yv);
plot(xv,yv,x(in),y(in),'r+',x(~in),y(~in),'bo')