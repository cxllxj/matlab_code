%��ɢ���ݵ�һά��ֵͼ
year=1900:10:2010;
product=[75.995 91.972 105.711 123.203 131.669 150.697 179.323 203.211 226.505 249.633 256.344 267.893];
p1995=interp1(year,product,1995)
x=1900:1:2010;
y=interp1(year,product,x,'pchip');
plot(year,product,'o',x,y)
