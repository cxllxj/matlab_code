function circle_f(r)
clf;t=0:pi/100:2*pi;x=r*exp(i*t);
plot(x,'r*');axis('square')
