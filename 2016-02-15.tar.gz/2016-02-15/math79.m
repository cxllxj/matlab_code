a=[20 30 100 100];
b=[50 60 300 400];
rectangle('position',[20 30 100 100])
rectangle('position',[50 60 300 400])
area=rectint(a,b)
