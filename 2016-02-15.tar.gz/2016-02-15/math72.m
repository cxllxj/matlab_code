x=(0:0.1:10)';
y1=trapmf(x,[2 3 7 9]);
y2=trapmf(x,[3 4 6 8]);
y3=trapmf(x,[4 5 5 7]);
y4=trapmf(x,[5 6 4 6]);
plot(x,[y1 y2 y3 y4]);
