fun='sum((x-0.2).^2)';
x0=[0.25,0.25,0.25];
[x,fval]=fseminf(fun,x0,1,@mycon1)
[C,Ceq,K1]=mycon1(x,[0.5,0.5]);
K1_m=max(max(K1))
