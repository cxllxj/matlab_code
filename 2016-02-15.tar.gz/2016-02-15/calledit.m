function calledit(hedit,hpop,hlist)
ct=get(hedit,'string');
vpop=get(hpop,'value');
vlist=get(hlist,'value');
if ~isempty(ct)
    eval(ct')
    popstr={'spring','summer','autumn','winter'};
    liststr={'grid on','box on','hidden off','axis off'};
    invstr={'grid off','box off','hidden on','axis on'};
    colormap(eval(popstr{vpop}))
    vv=zeros(1,4);vv(vlist)=1;
    for k=1:4
        if vv(k);eval(liststr{k};else eval(invstr{k});end
    end
end
