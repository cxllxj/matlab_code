rand('state',0);
x=rand(1,10);
y=rand(1,10);
TRI=delaunay(x,y);
triplot(TRI,x,y)
axis([0 1 0 1]);
hold on;
plot(x,y,'or');
hold off
