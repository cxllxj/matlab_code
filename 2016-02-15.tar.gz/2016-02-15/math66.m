data=normrnd(0,1,30,1);
p=capaplot(data,[-2,2])
