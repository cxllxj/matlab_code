n=5;a=0.9;
x_a=chi2inv(a,n);
x=0:0.1:15;yd_c=chi2pdf(x,n);
plot(x,yd_c,'b'),hold on
xxf=0:0.1:x_a;yyf=chi2pdf(xxf,n);
fill([xxf,x_a],[yyf,0],'g')
text(x_a*1.01,0.01,num2str(x_a))
text(10,0.10,['\fontsize{16}X~{\chi}^2(4)'])
text(1.5,0.05,'\fontsize{22}alpha=0.9')