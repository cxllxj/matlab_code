X=10*rand(4);Y=10*rand(4);Z=10*rand(4);
C=rand(4);
fill3(X,Y,Z,C)