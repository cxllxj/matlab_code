t=0:pi/10:2*pi;
[X Y Z]=cylinder(2+(cos(t)).^2);
surf(X,Y,Z);axis square
