function y=fzero_nestedfun(a,b,x0)
options=optimset('Display','off');
y=fzero(@para_fun,x0,options)

function y=para_fun(x)
y=exp(x)+a*x-b;
end

end
