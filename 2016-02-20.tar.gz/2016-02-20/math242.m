fid=fopen('math241.m','r');
data=fread(fid);
disp(char(data'))
