clear;
a=1;
b=-10:10;
x=zeros(size(b));
for i=1:length(b),
    x(i)=fzero_nestedfun(a,b(i),0);
end;
plot(b,x);
xlabel('b');
ylabel('���');