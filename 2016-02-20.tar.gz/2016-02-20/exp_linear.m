function y=exp_linear(x,a,b)
y=exp(x)+a*x-b;
