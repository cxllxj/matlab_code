function arc(x,y,radius,ang1,ang2)
%arc������˳ʱ�뷽���Բ��
%x,yΪԲ�����꣬radiusΪ�뾶
%ang1Ϊ��ʼ�ǣ�ang2Ϊ��ֹ��
%arc(20,10,100,45,315)
if radius>0
    ang1=450-ang1;
    ang2=450-ang2;
    if ang1>=360 && ang2>=360
        angtemp=ang1;
        ang1=ang2;
        ang2=angtemp;
    elseif ang1>=360
        ang1=ang1-360;
    elseif ang2>=360
        ang2=ang2-360;
    end
    
    ang1=ang1/180*pi;
    ang2=ang2/180*pi;
    
    t=ang1:pi/40:ang2;
    line(sin(t)*radius+x,cos(t)*radius+y)
end

    
rectangle('postion',[x-1,y-1,2,2])
axis equal


end

