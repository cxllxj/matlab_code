%new a script,math14
%�����Թ滮
%
f=[-7;-5];
A=[3 2
    4 6
    0 7];
b=[90;200;210];
lb=zeros(2,1);
[x,fval,exitflag,output,lambda]=linprog(f,A,b,[],[],lb)