%new a script,math35
%��ά��ֵ
%         
%          
%
[x,y]=meshgrid(-3:1:3);
z=peaks(x,y);
surf(x,y,z)
[xi,yi]=meshgrid(-3:0.25:3);
zi1=interp2(x,y,z,xi,yi,'nearest');
zi2=interp2(x,y,z,xi,yi,'bilinear');
zi3=interp2(x,y,z,xi,yi,'bicubic');
surf(xi,yi,zi1)
surf(xi,yi,zi2)
surf(xi,yi,zi3)
contour(xi,yi,zi1)
contour(xi,yi,zi2)
contour(xi,yi,zi3)