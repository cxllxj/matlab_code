%new a script,math22
%���Ŀ���Ż�����2
%
goal=[40 -800 -6];
weight=[40 -800 -6];
x0=[2 2];
A=[8 10;0 -1];
b=[40 -6];
lb=zeros(2,1);
options=optimset('MaxFunEvals',5000);
[x,fval,attainfactor,exitflag]=fgoalattain(@math22_myfun,x0,goal,weight,A,b,[],[],lb,[],[],options)