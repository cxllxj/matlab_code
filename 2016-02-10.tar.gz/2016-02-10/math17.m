A=[-1 0 0
    1 0 0
    0 -1 0
    0 1 0
    0 0 -1
    0 0 1];
b=[-1;4;-4.5;50;-10;30];
x0=[2.0;5.0;25.0];
lb=zeros(3,1);
[x,fval,exitflag,output,lambda]=fmincon(@math17_myfun1,x0,A,b,[],[],lb,[],@math17_myfun2)
