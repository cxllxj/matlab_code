function f=myfun(x)
f(1)=8*x(1)+10*x(2);
f(2)=-100*x(1)-100*x(2);
f(3)=-x(2);