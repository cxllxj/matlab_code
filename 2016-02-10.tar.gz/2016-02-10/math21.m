%new a script,math21
%���Ŀ���Ż�����1
%
goal=[20 12];
weight=[20 12];
x0=[2 5];
A=[1 0;0 1;-1 -1];
b=[5 6 -7];
lb=zeros(2,1);
[x,fval,attainfactor,exitflag]=fgoalattain(@math21_myfun,x0,goal,weight,A,b,[],[],lb,[])