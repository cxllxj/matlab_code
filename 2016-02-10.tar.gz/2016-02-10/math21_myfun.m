function f=myfun(x)
f(1)=2*x(1)+5*x(2);
f(2)=4*x(1)+x(2);