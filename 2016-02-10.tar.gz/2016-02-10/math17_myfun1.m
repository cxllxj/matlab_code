function f=myfun(x)
f=0.192457*1e-4*(x(2)+2)*x(1)^2*x(3);