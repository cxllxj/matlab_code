function Interplot
%UNTITLED6 Summary of this function goes here
%   Detailed explanation goes here
global istep
global xdata
global ydata
istep=0;
set(gcf,'pointer','cross');
set(gcf,'WindowButtonDownFcn',@WindowButtonDown);
set(gcf,'WindowButtonMotionFcn',@WindowButtonMotion);
    function WindowButtonDown(hObject,eventdata,handles)
        global istep
        global xdata
        global ydata
        global h
        istep=istep+1;
        p=get(gca,'currentpoint');
        if(istep==1)
           xdata(1)=p(1);
           ydata(1)=p(3);
           xdata(2)=p(1);
           ydata(2)=p(3);
           h=line(xdata,ydata,'EraseMode','xor');
        elseif(istep==2)
           xdata(2)=p(1);
           ydata(2)=p(3);
           set(h,'XData',xdata,'YData',ydata,'EraseMode','normal')
           istep=0;
        end
       function WindowButtonMotion(hObject,eventdata,handles)
        global istep
        global xdata
        global ydata
        global h
        p=get(gca,'currentpoint');
        if(istep==1)
           xdata(2)=p(1);
           ydata(2)=p(3); 
           set(h,'XData',xdata,'YData',ydata)
end

