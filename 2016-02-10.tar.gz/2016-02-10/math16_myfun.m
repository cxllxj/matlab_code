function f=myfun(x)
f=sin(x)+3;