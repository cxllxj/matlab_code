function y=fun(x)
y=[x(1)-0.5*sin(x(1))-0.3*cos(x(2)),x(2)-0.5*cos(x(1))+0.3*sin(x(2))]
    