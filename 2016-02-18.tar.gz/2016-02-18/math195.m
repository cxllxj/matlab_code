clear
x=[2 4 5 8 3];
y=[6 3 9 10 7];
bar(x,y);
%end