clear
x=0:0.1:2*pi;
y1=sin(3.*x);
y2=exp(x./3);
plot(x,y1,'*',x,y2,'+');
xlabel('t=0 to 2pi');
ylabel('value of sin(3t) and e^{x/3}')
y2=exp(x);
plotyy(x,y1,x,y2);
legend('���ҵĿ̶�','ָ���Ŀ̶�');

%end

 