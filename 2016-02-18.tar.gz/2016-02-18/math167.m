%f(x,y,z)=sqrt(x^2+y^2+z^2)+exp(x^2+y^2)+sin(x^2+z^2)��ƫ����
clear
F=sym('sqrt(x^2+y^2+z^2)+exp(x^2+y^2)+sin(x^2+z^2)');
dfdx=diff(F,'x')
dfdy=diff(F,'y')
dfdz=diff(F,'z')