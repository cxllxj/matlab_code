%����x->0,f(x)=(1+x)^(1/x)
clear
A=sym('(1+x)^(1/x)');
B=limit(A)
vpa(B,5)
