function Y=xxx(x,y)
Y=2*x-1;
