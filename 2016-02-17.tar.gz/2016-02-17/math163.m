%����y->0,f(x,y)=(sin(x+y)-sin(x))/y
clear
syms y;
A=sym('(sin(x+y)-sin(x))/y');
B=limit(A,y,0)

