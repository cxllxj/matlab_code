%����1/x->0+,f(x)=(1+a/x)^x && e^(-x)
clear
syms x;
A=sym('[(1+a/x)^x,exp(-x)]');
B=limit(A,x,inf,'left')