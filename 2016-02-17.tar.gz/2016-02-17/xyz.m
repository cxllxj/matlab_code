function fun=xyz(X)
x=X(1);y=X(2);z=X(3);
fun=zeros(3,1);
fun(1)=x+y+z;
fun(2)=x-y+3*z;
fun(3)=3*x+y-z-4;