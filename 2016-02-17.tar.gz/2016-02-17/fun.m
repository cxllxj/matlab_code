function Q=fun(T)
x=T(1);y=T(2);z=T(3);
Q=zeros(3,1);
Q(1)=x+y-z;
Q(2)=cos(x)+y^3+z-5;
Q(3)=4*x+2^y+log(z)-1;
