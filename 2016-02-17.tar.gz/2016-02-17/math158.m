%����
clear
f=sym('cos(x)^2+sqrt(x^2+2*x+1)+sin(x)^2')
F=simple(f)
G=simple(F)

