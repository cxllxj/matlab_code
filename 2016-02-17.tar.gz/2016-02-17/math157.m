%չ��
clear
f=sym('sin(x+y)/cos(2*x)+exp(x-y)+log(x*y^2)')
F=expand(f)
