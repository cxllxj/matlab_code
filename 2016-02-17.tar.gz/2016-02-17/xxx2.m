function Y=xxx2(x,y)
Y=5*y+(x-1)*sin(x)+(x+1)*cos(x);
