rand('state',5);
x=rand(1,10);y=rand(1,10);
[vx,vy]=voronoi(x,y);
plot(x,y,'r+',vx,vy,'b-');axis equal