X=[0.5 0
    0 0.5
    -0.5 -0.5
    -0.2 -0.1
    -0.1 0.1
    0.1 -0.1
    0.1 0.1]
[V,C]=voronoin(x)
for i=1:length(C),disp(C{i}),end