clear
x=1;
y=0;

for j=1:31
    y=x+y;
    fprintf('sum%g=%f\n',j,x)
    x=2.*x;
end
fprintf('Total=%f',y)