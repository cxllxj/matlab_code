
%1
load seamount
plot(x,y,'.','markersize',12)
xlabel('Longitude'),ylabel('Latitude')
grid on
%2
tri=delaunay(x,y);
hold on,triplot(tri,x,y),hold off