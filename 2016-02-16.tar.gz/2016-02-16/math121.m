clear
t=0:15:90;
A=sin(t.*pi/180);
B=asin(A).*180./pi;
A
B