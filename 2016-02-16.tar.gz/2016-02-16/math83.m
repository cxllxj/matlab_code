rand('state',5);
x=rand(1,10);y=rand(1,10);
voronoi(x,y)