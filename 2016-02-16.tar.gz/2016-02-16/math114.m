clear
x=0;
sum=0;
while x<101
    sum=sum+x;
    x=x+2;
end
sum
