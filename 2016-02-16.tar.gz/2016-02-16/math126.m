clear
[x]=meshgrid(-2:0.01:2);
z=(x.^2+x.^1);
mesh(z,x)
