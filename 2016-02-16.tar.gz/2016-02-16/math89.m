figure
hidden on
trimesh(tri,x,y,z)
grid on
xlabel('Longitude');ylabel('Latitude');zlabel('Depth in Feet')