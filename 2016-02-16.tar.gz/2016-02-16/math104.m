%��ʾ�ļ�math100.m������
% 1 and 2 all succ
%1
%fid=fopen('math100.m');
%2
fid=fopen('F:\can_lab_software\cxl\math100.m');
while 1
    tline=fgetl(fid);
    if ~ischar(tline),break,end
    disp(tline)
end
fclose(fid);
