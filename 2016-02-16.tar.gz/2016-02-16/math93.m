d=[-1 1];
[x,y,z]=meshgrid(d,d,d);
X=[x(:),y(:),z(:)];
X(9,:)=[0 0 0];
X=X+0.01*rand(size(X));
[V,C]=voronoin(X)
X=V(C{9},:);
K=convhulln(X);
figure
hold on
d=[1 2 3 1];
for i=1:size(K,1)
    j=K(i,d);
    h(i)=patch(X(j,1),X(j,2),X(j,3),i,'FaceAlpha',0.9);
end
hold off
view(3)
axis equal
title('One cell of a Voronoi diagram')

