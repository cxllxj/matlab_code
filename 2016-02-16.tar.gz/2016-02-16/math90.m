figure
[xi,yi]=meshgrid(210.8:.01:211.8,-48.5:.01:-47.9);
zi=griddata(x,y,z,xi,yi,'cubic');
[c,h]=contour(xi,yi,zi,'b-');
clabel(c,h)
xlabel('Longitude'),ylabel('Latitude')
