load('-ascii','data.txt');
data
