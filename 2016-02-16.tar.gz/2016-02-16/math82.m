%1
[x,y]=meshgrid(1:15,1:15);
tri=delaunay(x,y);
trisurf(tri,x,y,zeros(size(x)))

%2
z=peaks(15);
trisurf(tri,x,y,z)
%3
trimesh(tri,x,y,z)