clear
[A,xy]=bucky;
gplot(A(1:30,1:30),xy(1:30,:))
axis square