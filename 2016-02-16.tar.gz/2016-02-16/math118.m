clear
a=exp(2);
b=log(100);
c=log10(100);
d=log2(256);
[a b c d]