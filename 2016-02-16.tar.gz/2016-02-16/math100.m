[x,y,z]=peaks(20);
[dx,dy]=gradient(z,.2,.2);
contour(x,y,z)
hold on
quiver(x,y,dx,dy)
colormap autumn
grid off
hold off
