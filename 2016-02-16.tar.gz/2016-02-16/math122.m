clear
x=linspace(0,10,50);
y=sin(x).*exp(-x/3);
fill(x,y,'b')
figure,stem(x,y)
figure,stairs(x,y)
figure,errorbar(x,y,y)
figure,feather(x,y)