clear
x1=(0:0.01:5);
y1=log(x1);
x2=(-2:0.01:2);
y2=exp(x2);
plot(x1,y1,x2,y2)
