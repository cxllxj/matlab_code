clear
t=1:0.01:10;
y=8*(exp(0.8.*(-t)).*cos(10.*t));
plot(t,y)
axis([1 10 -1 1])
xlabel('Times-(t)');
ylabel('Current-(i)');
title('2-Dimension');
