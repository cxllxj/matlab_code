h=figure('ToolBar','none');
ht=uitoolbar(h);
a=rand(16,16,3);
htt=uitoggletool(ht,'CData',a,'TooltipString','Hello');
