d=[-1 1];
[x,y,z]=meshgrid(d,d,d);
X=[x(:),y(:),z(:)];
X(9,:)=[0 0 0];
T=delaunayn(X)
figure,hold on
d=[1 1 1 2;2 2 3 3;3 4 4 4];
for i=1:size(T,1)
    y=T(i,d);
    x1=reshape(X(y,1),3,4);
    x2=reshape(X(y,2),3,4);
    x3=reshape(X(y,3),3,4);
    h(i)=patch(x1,x2,x3,(1:4)*i,'FaceAlpha',0.9);
end
hold off
view(3),axis equal
axis off
camorbit(65,120)
title('Delaunay tessellation of a cube with a center point')