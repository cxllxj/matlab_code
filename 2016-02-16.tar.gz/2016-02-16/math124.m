clear
x=-pi:0.1:pi;
y=-pi:0.1:pi;
z=sin(x).*cos(y);
plot3(x,y,z)
figure,bar(z)
