clear
t=0:0.01:2*pi;
polar(t,abs(sin(t).*cos(t)))