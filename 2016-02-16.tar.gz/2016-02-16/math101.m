[X,Y,Z]=sphere;
[U,V,W]=surfnorm(X,Y,Z);
quiver3(X,Y,Z,U,V,W,0.8);
hold on
surf(X,Y,Z);
colormap hsv
view(-35,45)
axis equal
hold off
