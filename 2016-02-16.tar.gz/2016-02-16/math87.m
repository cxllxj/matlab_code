load seamount
plot(x,y,'.','markersize',10)
k=convhull(x,y);
hold on,plot(x(k),y(k),'-r'),hold off
grid on