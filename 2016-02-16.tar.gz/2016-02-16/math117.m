clear
x=[10 -25 30];
a=abs(x)
b=sign(x)
c=sqrt(x)
