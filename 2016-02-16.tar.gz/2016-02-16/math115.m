clear
a=100;
b=20;
if a<b
    fprintf('b>a')
else
    fprintf('a>b')
end
