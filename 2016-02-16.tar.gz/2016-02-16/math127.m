clear
subplot(2,2,1),fplot('[6*sin(x)]',2*pi*[-1 1 -1 1])
subplot(2,2,2),fplot('[3*cos(x)]',2*pi*[-1 1 -1 1])
subplot(2,2,3),fplot('[tan(x)]',2*pi*[-1 1 -1 1])
subplot(2,2,4),fplot('[sec(x)]',2*pi*[-1 1 -1 1])
