clear
[x,y]=meshgrid(-3.14:0.1:3.14);
z=sqrt((x.^2).*(y.^2));
mesh(x,y,z)
title('z=sqrt((x.^2).*(y.^2))');
