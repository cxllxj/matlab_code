fid=fopen('F:\can_lab_software\cxl\magic5.bin','wb');
fwrite(fid,magic(5),'integer*4')