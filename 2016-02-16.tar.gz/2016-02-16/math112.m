clear
for i=1:9;
    for j=1:9;
        a(i,j)=i*j;
    end
end
a